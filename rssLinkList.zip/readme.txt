  Plugin Name: RSS Fetched Link List
  Plugin URL: http://rawlinson.us/blog/?p=212
  Description: Allows you to display lists of links from an rss feed on your blog.
  Author: Bill Rawlinson
  Author URI: http://blog.rawlinson.us
  Version: 0.9.2



/* CHANGE LOG 
	DATE					MODIFICATION								AUTHOR
===========================================================================================
	06 January 2005			Initial Version								Bill Rawlinson - released version 0.1
	14 January 2005			Added ISO-8859-1 support					Bill Rawlinson
	14 January 2005			Added ISO-8859-1 sprt to description		Bill Rawlinson - released version 0.2
	20 January 2005			Show description as	the anchor title attrb.	Bill Rawlinson - thanks to Derek Gulbranson for the idea and initial implementation
	20 January 2005			fixed potential bug where title attrib
							could contain invalid characters such as	Bill Rawlinson - another tip of the hat to Derek
							quotes/double quotes
	24 January 2005			fixed typo that caused the seperator to		Bill Rawlinson - thanks to Derek again
							not appear
	31 January 2005			added support for connection timeout to		Bill Rawlinson - thanks to Ian (nontroppo.org) for suggesting it 
							handle case where remote URL is not
							available.  Changed lastrss.php to use fsockopen - so all RSS feeds must be identifiable by a URL
																						- released version 0.3
	30 March 2005			removed title attribute from link and updated description to handle special characters
																						- released version 0.4
	21 April 2005			added $sort property.						Bill Rawlinson - thanks to Brian Goodwin (http://www.fuddmain.com/)

	22 April 2005			added ability to call rssLinkList with		Bill Rawlinson	- released version 0.5
							named parameters "_rssLinkList"
	23 April 2005			grab all content in CDATA and display it	Bill Rawlinson - released version 0.6 - thanks to ahreno for the headsup
							this fixes ESPN feed display specifically
							but probably others as well

	25 April 2005			extracted settings to special functions		Bill Rawlinson - released version 0.7
							to make it easier for users to change them.
							updated readme.txt to make the named parameter
							call the perferred method (_rssLinkList())

	24 May 2005				added wordpress filter capabilities			Glenn Twiggs  - released version 0.8

	09 Jun 2005				fixed VERY obscure bug in lastRSS.php		Bill Rawlinson - released version 0.8.1
							that caused some, rare, occurances where
							part of the url query string was cut off

	09 Jun 2005				fixed filter bug that caused URLs that		Glenn Twiggs - released version 0.8.2
							included a hypen to be ignored.

	17 Jun 2005				added optional parameter to have links		Bill Rawlinson - released version 0.8.3
							open in a new window
	
	17 Jun 2005				more standards compliant way of supporing   Bill Rawlinson - released version 0.8.3.1
							new window links

	27 Jun 2005				added optional "simple" non-standards		Bill Rawlinson - released version 0.8.3.2
							complaint support for new windows as well

	12 Jul 2005				make it easier to enter the SETTINGS		Bill Rawlinson - released version 0.9
							also added an evaluator that should prevent
							any lastRSS already defined errors if another
							plugin is using it as require_once wasn't
							cutting it under that situation.  Added upgrade
							instructions to the readme.txt and update the install
							instructions.  Also, vastly improved the FILTER mechanism
							to support all parameters not just the URL

	25 Jul 2005				change named parameter call on Fitler usage Bill Rawlinson - released version 0.9.1
							from parameterName=parameterValue  to
							parameterName:=parameterValue in order to support URLs
							that contain arguments.
	01 Sep 2005				stopped hyperlinking items that don't have a link			- release version 0.9.1.1
							property provided in the rss feed - thanks Caleb
							in Oregon for pointing this one out.

	01 Sep 2005				wrapped the item title in a span and the description in		- release version 0.9.1.2
							a span.  The title has a class of rssLinkListItemTitle
							and the description has a class of rssLinkListItemDesc
							both available via CSS

	09 Sep 2009				deprecated the $debug parameter and added a new parameter	- released version 0.9.3
							of $ignore_cache.  ignore_cache should ONLY be set to true
							when testing or when using a feed that won't ban you for
							visiting too often.  As an example I am setting this to
							true on my "Recent Music" feed so that it is as up-to-date
							as possible.  There is a little trick to this, if you provide
							a number for ignore_cache it will use that number as the seconds
							to cache that specific feed for instance my recent_music is actually
							set to 120 so the cache expires every two minutes.

							Also, if you have no title but you do have a description the description
							will be wrapped in the hyperlink (if one exists)
*/



  DESCRIPTION:
  This plugin fetches RSS feeds from the url you provide displays them on your blog. It can be used to manage "hot links" sections or anything else you can grab via an RSS feed.

  The plugin also supports wordpress filters by letting you embed a feed into your post

  INSPIRATION:
  The initial idea for this plugin came from the del.icio.us plugin that can be found at http://chrismetcalf.net.
  
  LICENSE:
  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

  REQUIREMENTS:
  * WordPress 1.2 or greater (http://www.wordpress.org)
  * lastRSS (http://lastrss.webdot.cz/)

  INSTALLATION:
  1.) Put lastRss on your server where your PHP installation can get to it. I typically put it in my wp-content directory

  2.) Place the plugin (rssLinkList.php) in your wp-content/plugins/ directory.

  3.) Create a cache directory that your web server can write to. I created a folder inside wp-content named "rssCache" and chgrp/chmodded it to the proper group permissions (if all else fails try - 777; not very secure but it should help the cache work.  CACHING is not required for the plugin to work but it is recommended that you get it working).

  4.) Edit rssLinkList.php and fill out the values in the CONFIGURATION section.

  5.) Enable the RSS Fetched Link List plugin in the "Plugins" section of your WordPress administration panel.


  UPGRADING:
  1.) jot down your configuration information in rssLinkList.php 

  2.) Overwrite your lastRSS.php and rssLinkList.php files

  3.) Update your rssLinkList configuration information with that data you wrote down in step 1

  4.) enjoy


  USAGE:
  From anywhere in your WordPress template, call the function "rssLinkList(...)", which takes the following parameters (all parameters have default values):

		NOTE -> I now recommend using the _rssLinkList syntax to call instead of rssLinkList (which still works); as you can call using
				easier syntax with _rssLinkList if you want to change just a few of the parameters values using an associative array

  * rss_feed_url (default: "http://del.icio.us/rss") - The URL of the Del.icio.us RSS Feed
  * num_items (default: 15) - The number of items to display
  * show_description (default: true) - Whether or not to display the "description" field
  * random (default: false) - Whether or not to randomize the items
  * before (default: "<li>") - Tag placed before the item
  * after (default: "</li>") - Tag placed after the item
  * description_seperator (default: " - ") - Between the link and the item
  * encoding (default: false) - Change to true if you are reading in a ISO-8859-1 formatted file.  Basically, if you see a bunch of question marks (?) in your titles
								set this to true and see if it fixes the problem.
  * sort (default: "none") - takes one of three values; none, asc, desc
			none - doesn't sort and leaves your existing code as is
			asc	 - sorts the results in alphabetic order (by title)
			desc - sorts in reverse alphabetic order (by title)

  * new_window (default: false) - Whether to open the links in a new window or not.
			true - opens links in new window using javascript to attach the "target" attribute to each link in the list
					and is thus xhtml strict compliant
			false - opens the links in the current window  (DEFAULT)
			simple - opens links in new window and hardcodes the target="_blank" into the link. NOT xhtml strict compliant
					this option exists so that you can use it without javascript.  If you also don't want to include the javascript
					in your header file update the global setting in rssLinkList.php $showRSSLinkListJS and set it to false.


	FILTER USAGE

		* basic:
			<!--rss:[URL]--> 

			NOTE if you aren't using named parameters with the fitler then ONLY provide the url after the rss: or else it won't work

		* NAMED PARAMETERS

			<!--rss:rss_feed_url:=http://del.icio.us/rss/finalcut/wishlist,num_items:=5,random:=true-->

			NOTE when using the filter and named parameters ALL parameters including the URL must be named. Also note that if
			you are providing different HTML for the before or after parameter you must escape it.  For instance if you want before='<li>'
			then you must pass before='&lt;li&gt;'  

			Finally note the whole thing must be on ONE line.  No line breaks or else it won't work.




  EXAMPLES:

NAMED PARAMETER EXAMPLE -- PREFERRED METHOD
	<ol>
	<?php _rssLinkList(array("rss_feed_url"=>"http://www.auf-der-hoehe.de/index.php?id=23&type=333&feed_id=71&no_cache=1",
						"num_items"=>10,
						"show_description"=>false,
						"random"=>true,
						"sort"=>"asc","new_window"=>true)); ?>
	</ol>




BASIC
	<ol>
	 <?php 
		rssLinkList("http://del.icio.us/rss/finalcut"); 
	 ?>
	</ol>

	due to the fact that rssLinkList wraps each item with an <li> tag pair by default you need to provide the <ol> or <ul> wrappers
	around the function call.




ADVANCED

	Here is a simple example using yahoo news RSS feeds and specifying EVERY parameter.:

	rssLinkList("http://rss.news.yahoo.com/rss/topstories",5,true,true,"--&nbsp;","<br />","&mdash;");


	This example will grab the yahoo news TOP STORIES news feed, randomize the resultant items, and display the five of the random items along 
	with their descriptions. Before each item it will display two dashes and a blank space.  Each item will be followed by a <br /> tag thus
	creating a newline.  Finally, the description will be separated from the title by a long dash (&mdash;).


COMBINING LISTS:

	You can also combine rss calls into one html list simply by wrapping multiple rssLinkList function calls
	in one set of html list tags.  Notice I only specify the first parameter here.  All parameters have defaults
	so the only one you really need to provide is the URL.

	<ol>
	 <?php 
		rssLinkList("http://del.icio.us/rss/finalcut"); 
		rssLinkList("http://www.43things.com/rss/uber/author?username=FinalCut");
	 ?>
	</ol>

	since the function, rssLinkList, by default wraps each rss item in <li> tags you will end up with
	one long list of items to display.

ENCODING EXAMPLE:

	<ol>
	<?php rssLinkList("http://www.auf-der-hoehe.de/index.php?id=23&type=333&feed_id=71&no_cache=1",10,false,true,"<li>","</li>","-",true); ?>
	</ol>


FILTER EXAMPLE
		<!--rss:http://del.icio.us/rss/finalcut-->


NOTE:
Remember, if you don't want your items to be displayed as an html list - you need to override the default parameters of "before" and "after"
in the function call.